declare interface IUserProfileViewerWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'UserProfileViewerWebPartStrings' {
  const strings: IUserProfileViewerWebPartStrings;
  export = strings;
}
