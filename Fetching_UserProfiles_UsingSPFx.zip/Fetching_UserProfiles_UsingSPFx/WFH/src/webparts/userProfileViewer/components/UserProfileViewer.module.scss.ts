/* tslint:disable */
require("./UserProfileViewer.module.css");
const styles = {
  userProfileViewer: 'userProfileViewer_40f7c524',
  container: 'container_40f7c524',
  row: 'row_40f7c524',
  column: 'column_40f7c524',
  'ms-Grid': 'ms-Grid_40f7c524',
  title: 'title_40f7c524',
  subTitle: 'subTitle_40f7c524',
  description: 'description_40f7c524',
  button: 'button_40f7c524',
  label: 'label_40f7c524'
};

export default styles;
/* tslint:enable */