import * as React from 'react';
import styles from './UserProfileViewer.module.scss';
import { IUserProfileViewerProps } from './IUserProfileViewerProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { IDataService } from '../services/IDataService';
import { UserProfileService } from '../services/UserProfileService';
import { SPHttpClient, SPHttpClientResponse } from '@microsoft/sp-http';
import { ServiceScope, Environment, EnvironmentType, Guid } from '@microsoft/sp-core-library';
import { IUserProfileViewerState } from './IUserProfileViewerState';
import { IUserProfile } from '../components/IUserProfile';
import  { sp } from '@pnp/pnpjs';
import SPService from '../services/SPServices';
import * as jquery from 'jquery';
import { default as pnp, ItemAddResult } from "sp-pnp-js";
import { FontWeights } from 'office-ui-fabric-react/lib/Styling';


let date = new Date().getDate();
let month = new Date().getMonth() + 1;
let year = new Date().getFullYear();
var months = [undefined, 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
var monthname = months[month];


export class UserProfile implements IUserProfile {
  FirstName: string;
  LastName: string;
  Email: string;
  Title: string;
  WorkPhone: string;
  DisplayName: string;
  Department: string;
  PictureURL: string;
  Manager_L1: string;
  Manager_L2: string;
  Manager_L5: string;
  UserProfileProperties: Array<any>;
  ExtendedManagers: Array<any>;
  AccountName: string;

}

export default class UserProfileViewer extends React.Component<
  IUserProfileViewerProps,
  IUserProfileViewerState>
{
  private dataCenterServiceInstance: IDataService;
  private SPService: SPService;

  constructor(props: IUserProfileViewerProps, state: IUserProfileViewerState) {
    super(props);

    let userProfile: IUserProfile = new UserProfile();
    userProfile.FirstName = "";
    userProfile.LastName = "";
    userProfile.Email = "";
    userProfile.Title = "";
    userProfile.WorkPhone = "";
    userProfile.DisplayName = "";
    userProfile.Department = "";
    userProfile.PictureURL = "";
    userProfile.Manager_L1 = "";
    userProfile.Manager_L2 = "";
    userProfile.Manager_L5 = "";
    userProfile.UserProfileProperties = [];
    userProfile.ExtendedManagers = [];
    userProfile.AccountName = "";


    this.SPService = new SPService(this.props.context);
    this.state = {
      userProfileItems: userProfile,
      HRName: String,
      WFH_submitted_currentmonth: String,
      HREmail:String
    };

  }
 

  public componentWillMount(): void {
    let serviceScope: ServiceScope = this.props.serviceScope;
    this.dataCenterServiceInstance = serviceScope.consume(UserProfileService.serviceKey);

    this.dataCenterServiceInstance.getUserProfileProperties().then(async (userProfileItems: IUserProfile) => {
      for (let i: number = 0; i < userProfileItems.UserProfileProperties.length; i++) {
        if (userProfileItems.UserProfileProperties[i].Key == "FirstName") {
          userProfileItems.FirstName = userProfileItems.UserProfileProperties[i].Value;
        }

        if (userProfileItems.UserProfileProperties[i].Key == "LastName") {
          userProfileItems.LastName = userProfileItems.UserProfileProperties[i].Value;
        }

        if (userProfileItems.UserProfileProperties[i].Key == "Title") {
          userProfileItems.WorkPhone = userProfileItems.UserProfileProperties[i].Value;
        }

        if (userProfileItems.UserProfileProperties[i].Key == "Department") {
          userProfileItems.Department = userProfileItems.UserProfileProperties[i].Value;
        }

        if (userProfileItems.UserProfileProperties[i].Key == "PictureURL") {
          userProfileItems.PictureURL = userProfileItems.UserProfileProperties[i].Value;
        }
        if (userProfileItems.UserProfileProperties[i].Key == "WorkEmail") {
          userProfileItems.Email = userProfileItems.UserProfileProperties[i].Value;
        }

        if (userProfileItems.UserProfileProperties[i].Key == "AccountName") {
          userProfileItems.AccountName = userProfileItems.UserProfileProperties[i].Value;
        }


      }

      let mngr_1;
      let mngr_2;
      let mngr_5;


      mngr_1 = await sp.web.ensureUser(userProfileItems.ExtendedManagers[userProfileItems.ExtendedManagers.length - 1]);
      mngr_2 = await sp.web.ensureUser(userProfileItems.ExtendedManagers[userProfileItems.ExtendedManagers.length - 2]);

      if (userProfileItems.ExtendedManagers[4] != null) {
        mngr_5 = await sp.web.ensureUser(userProfileItems.ExtendedManagers[4]);
        userProfileItems.Manager_L5 = mngr_5.data.Title;
      }
      else if (userProfileItems.ExtendedManagers[4] == null) {
        mngr_5 = await sp.web.ensureUser(userProfileItems.AccountName);
        userProfileItems.Manager_L5 = userProfileItems.LastName + ', ' + userProfileItems.FirstName;

      }

      userProfileItems.Manager_L1 = mngr_1.data.Title;
      userProfileItems.Manager_L2 = mngr_2.data.Title;      
      this.GetHr_from_List(mngr_5.data.Email);

      this.setState({ userProfileItems: userProfileItems });
      this.Get_Approved_Pending_Rejected_WFHCount(userProfileItems.Email);
      
     
      this.createItem(userProfileItems.Email, mngr_5.data.Email);
    });
  }
  public GetHr_from_List(L5email: string) {
    var reactHandler = this;
    jquery.ajax({
      url: `${this.props.siteurl}/_api/web/lists/getbytitle('HRBP%20Mapping%20List')/items?$select=HRManager/EMail,HRManager/Title,L5Manager/EMail&$filter=L5Manager/EMail eq '` + L5email + `'&$expand=HRManager,L5Manager`,
      type: "GET",
      headers: { 'Accept': 'application/json; odata=verbose;' },
      success: function (resultData) {

        var x = resultData.d.results;

        reactHandler.setState({
          HRName: (x[0].HRManager.Title),
          HREmail:(x[0].HRManager.EMail)


        });

      },
      error: function (jqXHR, textStatus, errorThrown) {
      }
    });
  }
  public Get_Approved_Pending_Rejected_WFHCount(useremail: string) {
    let wfhcount: Number = 0;
    var reactHandler = this;
    jquery.ajax({
      url: `${this.props.siteurl}/_vti_bin/listdata.svc/WFHList?$select=EmployeeName/WorkEmail,DaysRequestingFor&$expand=EmployeeName&$filter=month(StartDate) eq ` + month + ` and year(StartDate) eq ` + year + ` and EmployeeName/WorkEmail eq '` + useremail + `' and Status ne 'Rejected'`,

      type: "GET",
      headers: { 'Accept': 'application/json; odata=verbose;' },
      success: function (resultData) 
      {

        var Listitemcount = resultData.d.results.length;
        for (var i = 0; i < Listitemcount; i++) {
          wfhcount += resultData.d.results[i].DaysRequestingFor;


        }


        reactHandler.setState({
          WFH_submitted_currentmonth: (wfhcount)


        });

      },
      error: function (jqXHR, textStatus, errorThrown) {
      }
    });
  }


  public render(): React.ReactElement<IUserProfileViewerProps> {
    return (
      <div  className={styles.userProfileViewer}>
        <div className={styles.container}>
          <div className={styles.row}>
          
            <div className={styles.column}>            
              

              {/* <img src={this.state.userProfileItems.PictureURL}></img> */}
              <p id='mydetails' style={{fontSize: '24px',fontWeight:100}}>My Details</p>
              <p>
                <b>Name:</b> {this.state.userProfileItems.LastName}, {this.state.userProfileItems.FirstName}
              </p>
              <p>
                <b>Hard Line Manager:</b> {this.state.userProfileItems.Manager_L1}

              </p>
              <p>
                <b>Second Level Manager:</b> {this.state.userProfileItems.Manager_L2}
              </p>
              <p>
                <b>L5 Manager:</b> {this.state.userProfileItems.Manager_L5}
              </p>

              <p>
                <b>HRBP:</b> {this.state.HRName}
              </p>
              <p>
                <b>WFH submitted for {monthname} -{year}:</b> {this.state.WFH_submitted_currentmonth}
              </p>      

            </div>
          </div>
        </div>
      </div>
    );
  }

  
  
  private createItem(username: string, L5name: string): void 
  {

   // const web: Web = new Web(this.props.siteurl);
   pnp.sp.web.lists.getByTitle("Emp_L5_Mapping").items.add
      (
        {
         
          UserName: username,
          L5Name: L5name,
          

        }
      ).then((result: ItemAddResult):void => 
      {
        console.log(result);
        console.log(pnp.sp.web);

      },
   
        (error: any): void => 
        {  
          console.log(error);
          console.log(pnp.sp.web);
          
        });   
     
      
  }


}
