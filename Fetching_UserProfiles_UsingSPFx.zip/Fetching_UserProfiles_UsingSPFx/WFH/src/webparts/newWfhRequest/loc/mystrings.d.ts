declare interface INewWfhRequestWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'NewWfhRequestWebPartStrings' {
  const strings: INewWfhRequestWebPartStrings;
  export = strings;
}
