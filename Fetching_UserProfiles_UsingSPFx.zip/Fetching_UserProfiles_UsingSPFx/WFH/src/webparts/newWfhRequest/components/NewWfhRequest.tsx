import * as React from 'react';
import styles from './NewWfhRequest.module.scss';
import { INewWfhRequestProps } from './INewWfhRequestProps';
import { escape } from '@microsoft/sp-lodash-subset';
import { INewWFHRequestForm } from '../Model/INewWFHRequestForm';
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import { TaxonomyPicker, IPickerTerms } from "@pnp/spfx-controls-react/lib/TaxonomyPicker";
import { PeoplePicker } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { default as pnp, ItemAddResult } from "sp-pnp-js";
import { Dialog, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';
import { PrimaryButton, DefaultButton } from 'office-ui-fabric-react/lib/components/Button';
import { Toggle } from 'office-ui-fabric-react/lib/Toggle';
import { Dropdown, IDropdownOption } from 'office-ui-fabric-react/lib/Dropdown';
import { Checkbox } from 'office-ui-fabric-react/lib/Checkbox';
import { Panel, PanelType } from 'office-ui-fabric-react/lib/Panel';
import { Label } from 'office-ui-fabric-react/lib/Label';
import { DatePicker, DayOfWeek, IDatePickerStrings } from 'office-ui-fabric-react/lib/DatePicker';
import { addMonths, addYears } from 'office-ui-fabric-react/lib/utilities/dateMath/DateMath';
import { mergeStyleSets } from 'office-ui-fabric-react/lib/Styling';

const today: Date = new Date(Date.now());
const minDate: Date = addMonths(today, -1);
const maxDate: Date = addYears(today, 1);

const DayPickerStrings: IDatePickerStrings = {
  months: [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December'
  ],

  shortMonths: [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ],

  days: [
    'Sunday',
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday'
  ],

  shortDays: [
    'S',
    'M',
    'T',
    'W',
    'T',
    'F',
    'S'
  ],

  goToToday: 'Go to today',
  prevMonthAriaLabel: 'Go to previous month',
  nextMonthAriaLabel: 'Go to next month',
  prevYearAriaLabel: 'Go to previous year',
  nextYearAriaLabel: 'Go to next year',
  closeButtonAriaLabel: 'Close date picker',

  //isRequiredErrorMessage: 'Date is required.',
  //invalidInputErrorMessage: 'Invalid date format.',
  isOutOfBoundsErrorMessage: `Date must be between ${minDate.toLocaleDateString()}-${maxDate.toLocaleDateString()}`
};



const controlClass = mergeStyleSets({
  control: {
    margin: '0 0 15px 0',
    maxWidth: '300px'
  }
});

export default class NewWfhRequest extends React.Component<INewWfhRequestProps, INewWFHRequestForm> {

  constructor(props: INewWfhRequestProps, state: INewWFHRequestForm) {
    super(props);

    this.handleTitle = this.handleTitle.bind(this);
    
    
    this._onCheckboxChange = this._onCheckboxChange.bind(this);
    this.state = {
      name: "",
      description: "",
      selectedItems: [],
      hideDialog: true,
      showPanel: false,
      dpselectedItem: undefined,
      dpselectedItems: [],
      disableToggle: false,
      defaultChecked: false,
      termKey: undefined,
      userIDs: [],
      userManagerIDs: [],
      pplPickerType: "",
      status: "",
      isChecked: false,
      required: "This is required",
      onSubmission: false,
      termnCond: false,

      totalappliedWFH_inmonth: "",
      firstDayOfWeek: DayOfWeek.Sunday,
      value_Start: null,
      value_End: null,
      noofWFHrequesting: "",
      comments_reason: ""
    }
  }


  // public render(): React.ReactElement<INewWfhRequestProps> 
  public render(): JSX.Element {
    const { dpselectedItem, dpselectedItems } = this.state;
    const { name, description } = this.state;
    const { firstDayOfWeek} = this.state;


    const desc = 'This field is required. One of the support input formats is year dash month dash day.';

    pnp.setup({
      spfxContext: this.props.context
    });

    return (
      <form>
        <div className={styles.newWfhRequest}>
          <div className={styles.container}>
            <div className={`ms-Grid-row ms-bgColor-neutralLight ms-fontColor-white ${styles.row}`}>

              <div className="ms-Grid-col ms-u-sm4 block">
                <label className="ms-Label">WFH Applied</label>
              </div>
              <div className="ms-Grid-col ms-u-sm8 block">
                <Label defaultValue={this.state.totalappliedWFH_inmonth}></Label>
              </div>

              <div className="ms-Grid-col ms-u-sm4 block">
                <label className="ms-Label">Start Date</label>
              </div>

              <div className="ms-Grid-col ms-u-sm4 block">
                <DatePicker id='startdate'
                 className={controlClass.control}
                  isRequired={true}
                  allowTextInput={false}
                  ariaLabel={desc}
                  firstDayOfWeek={firstDayOfWeek}
                  strings={DayPickerStrings}
                  onSelectDate={this. _onSelectStartDate}
                  placeholder='Select a Start Date...' />
              </div>

              <div className="ms-Grid-col ms-u-sm4 block">
                <label className="ms-Label">End Date</label>
              </div>

              <div className="ms-Grid-col ms-u-sm4 block">
                <DatePicker id='enddate'
                  isRequired={true}
                  allowTextInput={false}
                  ariaLabel={desc}
                  firstDayOfWeek={firstDayOfWeek}
                  strings={DayPickerStrings}
                  onSelectDate={this. _onSelectEndDate}
                  placeholder='Select a End Date...'
                />
              </div>

              <div className="ms-Grid-col ms-u-sm4 block">
                <label className="ms-Label">Requesting</label>
              </div>
              <div className="ms-Grid-col ms-u-sm8 block">
                <TextField value={this.state.noofWFHrequesting} disabled={false} />

              </div>
              <div className="ms-Grid-col ms-u-sm4 block">
                <label className="ms-Label">Reason</label><br />
              </div>
              <div className="ms-Grid-col ms-u-sm8 block">
                <Dropdown
                  placeHolder="Select an Option"
                  label=""
                  id="component"
                  selectedKey={dpselectedItem ? dpselectedItem.key : undefined}
                  ariaLabel="Basic dropdown example"
                  options={[
                    { key: 'Human Resource', text: 'Reason 1' },
                    { key: 'Finance', text: 'Reason 2' },
                    { key: 'Employee', text: 'Reason 3' }
                  ]}
                  onChanged={this._changeState}
                  onFocus={this._log('onFocus called')}
                  onBlur={this._log('onBlur called')}
                />
              </div>

              <div className="ms-Grid-col ms-u-sm4 block">
                <label className="ms-Label"></label>
              </div>
              <div className="ms-Grid-col ms-u-sm8 block">
                <TextField multiline autoAdjustHeight value={this.state.description} onChanged={this.handleDesc}
                />
              </div>

              <div className="ms-Grid-col ms-u-sm1 block">
                <Checkbox onChange={this._onCheckboxChange} ariaDescribedBy={'descriptionID'} />
              </div>
              <div className="ms-Grid-col ms-u-sm11 block">
                <span className={`${styles.customFont}`}>I confirm that I am not on bench and in ODC where WFH is not allowed</span><br />
                <p className={(this.state.termnCond === false && this.state.onSubmission === true) ? styles.fontRed : styles.hideElement}>Please check the Terms & Condition</p>
              </div>
              <div className="ms-Grid-col ms-u-sm6 block">
              </div>
              <div className="ms-Grid-col ms-u-sm2 block">
                <PrimaryButton text="Create" onClick={() => { this.validateForm(); }} />
              </div>
              <div className="ms-Grid-col ms-u-sm2 block">
                <DefaultButton text="Cancel" onClick={() => { this.setState({}); }} />
              </div>
              <div>
                <Panel
                  isOpen={this.state.showPanel}
                  type={PanelType.smallFixedFar}
                  onDismiss={this._onClosePanel}
                  isFooterAtBottom={false}
                  headerText="Are you sure  to create a new WFH Request?"
                  closeButtonAriaLabel="Close"
                  onRenderFooterContent={this._onRenderFooterContent}
                ><span>Please check the details filled and click on Confirm button to create new WFH Request.</span>
                </Panel>
              </div>
              <Dialog
                hidden={this.state.hideDialog}
                onDismiss={this._closeDialog}
                dialogContentProps={{
                  type: DialogType.largeHeader,
                  title: 'Request Submitted Successfully',
                  subText: ""
                }}
                modalProps={{
                  titleAriaId: 'myLabelId',
                  subtitleAriaId: 'mySubTextId',
                  isBlocking: false,
                  containerClassName: 'ms-dialogMainOverride'
                }}>
                <div dangerouslySetInnerHTML={{ __html: this.state.status }} />
                <DialogFooter>
                  <PrimaryButton onClick={() => this.gotoHomePage()} text="Okay" />
                </DialogFooter>
              </Dialog>
              {/* <DefaultButton onClick={ () => this.setState({ value: null }) } text='Clear' />  
<br/> 
<br/> 
<DatePicker firstDayOfWeek={ firstDayOfWeek } strings={ DayPickerStrings } placeholder='Select a date...' />  */}

            </div>
          </div>
        </div>
      </form>
    );
  }
  private _onSelectStartDate = (date: Date | null | undefined): void => 
  {
    this.setState({ value_Start: date });
  };
  private _onSelectEndDate = (date: Date | null | undefined): void => 
  {
    this.setState({ value_End: date });
  };

  private onTaxPickerChange(terms: IPickerTerms) {
    this.setState({ termKey: terms[0].key.toString() });
    console.log("Terms", terms);
  }

  private _getManager(items: any[]) {
    this.state.userManagerIDs.length = 0;
    for (let item in items) {
      this.state.userManagerIDs.push(items[item].id);
      console.log(items[item].id);
    }
  }

  private _onRenderFooterContent = (): JSX.Element => {
    return (
      <div>
        <PrimaryButton onClick={this.createItem} style={{ marginRight: '8px' }}>
          Confirm
      </PrimaryButton>
        <DefaultButton onClick={this._onClosePanel}>Cancel</DefaultButton>
      </div>
    );
  }

  private _log(str: string): () => void {
    return (): void => {
      console.log(str);
    };
  }

  private _onClosePanel = () => {
    this.setState({ showPanel: false });
  }

  private _onShowPanel = () => {
    this.setState({ showPanel: true });
  }

  private _changeSharing(checked: any): void {
    this.setState({ defaultChecked: checked });
  }

  private _changeState = (item: IDropdownOption): void => {
    console.log('here is the things updating...' + item.key + ' ' + item.text + ' ' + item.selected);
    this.setState({ dpselectedItem: item });
    if (item.text == "Employee") {
      this.setState({ defaultChecked: false });
      this.setState({ disableToggle: true });
    }
    else {
      this.setState({ disableToggle: false });
    }
  }

  private handleTitle(value: string): void {
    return this.setState({
      name: value
    });
  }

  private handleDesc(value: string): void {
    return this.setState({
      description: value
    });
  }

  private _onCheckboxChange(ev: React.FormEvent<HTMLElement>, isChecked: boolean): void {
    console.log(`The option has been changed to ${isChecked}.`);
    this.setState({ termnCond: (isChecked) ? true : false });
  }

  private _closeDialog = (): void => {
    this.setState({ hideDialog: true });
  }

  private _showDialog = (status: string): void => {
    this.setState({ hideDialog: false });
    this.setState({ status: status });
  }

  private validateForm(): void {
    let allowCreate: boolean = true;
    this.setState({ onSubmission: true });

    if (this.state.name.length === 0) {
      allowCreate = false;
    }
    if (this.state.termKey === undefined) {
      allowCreate = false;
    }

    if (allowCreate) {
      this._onShowPanel();
    }
    else {
      //do nothing
    }
  }

  private gotoHomePage(): void {
    window.location.replace(this.props.siteurl);
  }

  private createItem(): void {
    this._onClosePanel();
    this._showDialog("Submitting Request");
    console.log(this.state.termKey);
    pnp.sp.web.lists.getByTitle("Employee Registeration").items.add({
      Title: this.state.name,
      Description: this.state.description,
      Department: this.state.dpselectedItem.key,
      Projects: {
        __metadata: { "type": "SP.Taxonomy.TaxonomyFieldValue" },
        Label: "1",
        TermGuid: this.state.termKey,
        WssId: -1
      },
      Reporting_x0020_ManagerId: this.state.userManagerIDs[0]
    }).then((iar: ItemAddResult) => {
      this.setState({ status: "Your request has been submitted sucessfully " });
    });
  }
}