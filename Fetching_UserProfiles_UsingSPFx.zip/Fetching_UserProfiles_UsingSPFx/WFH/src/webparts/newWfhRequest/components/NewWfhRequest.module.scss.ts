/* tslint:disable */
require("./NewWfhRequest.module.css");
const styles = {
  newWfhRequest: 'newWfhRequest_baae9f93',
  container: 'container_baae9f93',
  row: 'row_baae9f93',
  column: 'column_baae9f93',
  'ms-Grid': 'ms-Grid_baae9f93',
  title: 'title_baae9f93',
  subTitle: 'subTitle_baae9f93',
  description: 'description_baae9f93',
  button: 'button_baae9f93',
  label: 'label_baae9f93',
  fontRed: 'fontRed_baae9f93',
  hideElement: 'hideElement_baae9f93',
  hideElementManager: 'hideElementManager_baae9f93',
  customFont: 'customFont_baae9f93'
};

export default styles;
/* tslint:enable */