import { WebPartContext } from '@microsoft/sp-webpart-base';

export interface INewWfhRequestProps {
  description: string;
  context: WebPartContext;
  siteurl: string;
}
