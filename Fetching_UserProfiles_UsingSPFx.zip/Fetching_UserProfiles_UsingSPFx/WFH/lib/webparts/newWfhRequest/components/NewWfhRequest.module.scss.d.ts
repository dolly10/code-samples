declare const styles: {
    newWfhRequest: string;
    container: string;
    row: string;
    column: string;
    'ms-Grid': string;
    title: string;
    subTitle: string;
    description: string;
    button: string;
    label: string;
    fontRed: string;
    hideElement: string;
    hideElementManager: string;
    customFont: string;
};
export default styles;
//# sourceMappingURL=NewWfhRequest.module.scss.d.ts.map