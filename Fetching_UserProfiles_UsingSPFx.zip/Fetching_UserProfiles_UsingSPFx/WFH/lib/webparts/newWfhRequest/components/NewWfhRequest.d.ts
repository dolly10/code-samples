import * as React from 'react';
import { INewWfhRequestProps } from './INewWfhRequestProps';
import { INewWFHRequestForm } from '../Model/INewWFHRequestForm';
export default class NewWfhRequest extends React.Component<INewWfhRequestProps, INewWFHRequestForm> {
    constructor(props: INewWfhRequestProps, state: INewWFHRequestForm);
    render(): JSX.Element;
    private _onSelectStartDate;
    private _onSelectEndDate;
    private onTaxPickerChange;
    private _getManager;
    private _onRenderFooterContent;
    private _log;
    private _onClosePanel;
    private _onShowPanel;
    private _changeSharing;
    private _changeState;
    private handleTitle;
    private handleDesc;
    private _onCheckboxChange;
    private _closeDialog;
    private _showDialog;
    private validateForm;
    private gotoHomePage;
    private createItem;
}
//# sourceMappingURL=NewWfhRequest.d.ts.map