import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration } from '@microsoft/sp-webpart-base';
import "@pnp/polyfill-ie11";
import "polyfill-array-includes";
export interface IUserProfileViewerWebPartProps {
    description: string;
}
export default class UserProfileViewerWebPart extends BaseClientSideWebPart<IUserProfileViewerWebPartProps> {
    onInit(): Promise<void>;
    render(): void;
    protected onDispose(): void;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=UserProfileViewerWebPart.d.ts.map