import { IUserProfile } from '../components/IUserProfile';
export interface IDataService {
    [x: string]: any;
    getUserProfileProperties: () => Promise<IUserProfile>;
}
//# sourceMappingURL=IDataService.d.ts.map