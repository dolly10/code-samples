import { ServiceScope, ServiceKey } from "@microsoft/sp-core-library";
import { IUserProfile } from '../components/IUserProfile';
import { IDataService } from './IDataService';
export declare class UserProfileService implements IDataService {
    static readonly serviceKey: ServiceKey<IDataService>;
    private _spHttpClient;
    private _pageContext;
    private _currentWebUrl;
    constructor(serviceScope: ServiceScope);
    getUserProfileProperties(): Promise<IUserProfile>;
    private readUserProfile;
    private processUserProfile;
}
//# sourceMappingURL=UserProfileService.d.ts.map