export interface IUserProfile {
    ExtendedManagers: Array<any>;
    FirstName: string;
    LastName: string;
    Email: string;
    Title: string;
    WorkPhone: string;
    DisplayName: string;
    Department: string;
    PictureURL: string;
    Manager_L1: string;
    Manager_L2: string;
    Manager_L5: string;
    UserProfileProperties: Array<any>;
    AccountName: string;
}
//# sourceMappingURL=IUserProfile.d.ts.map