import { IUserProfile } from '../components/IUserProfile';
export interface IUserProfileViewerState {
    userProfileItems: IUserProfile;
    HRName: any;
    WFH_submitted_currentmonth: any;
    HREmail: any;
}
//# sourceMappingURL=IUserProfileViewerState.d.ts.map