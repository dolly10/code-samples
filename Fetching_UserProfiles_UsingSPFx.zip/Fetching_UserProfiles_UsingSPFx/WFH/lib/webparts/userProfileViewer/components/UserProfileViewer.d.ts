import * as React from 'react';
import { IUserProfileViewerProps } from './IUserProfileViewerProps';
import { IUserProfileViewerState } from './IUserProfileViewerState';
import { IUserProfile } from '../components/IUserProfile';
export declare class UserProfile implements IUserProfile {
    FirstName: string;
    LastName: string;
    Email: string;
    Title: string;
    WorkPhone: string;
    DisplayName: string;
    Department: string;
    PictureURL: string;
    Manager_L1: string;
    Manager_L2: string;
    Manager_L5: string;
    UserProfileProperties: Array<any>;
    ExtendedManagers: Array<any>;
    AccountName: string;
}
export default class UserProfileViewer extends React.Component<IUserProfileViewerProps, IUserProfileViewerState> {
    private dataCenterServiceInstance;
    private SPService;
    constructor(props: IUserProfileViewerProps, state: IUserProfileViewerState);
    componentWillMount(): void;
    GetHr_from_List(L5email: string): void;
    Get_Approved_Pending_Rejected_WFHCount(useremail: string): void;
    render(): React.ReactElement<IUserProfileViewerProps>;
    private createItem;
}
//# sourceMappingURL=UserProfileViewer.d.ts.map